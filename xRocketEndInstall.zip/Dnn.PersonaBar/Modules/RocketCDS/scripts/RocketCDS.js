'use strict';
define(['jquery'],
    function () {
 
        return {
            init: function (wrapper, util, params, callback) {
            },
 
            initMobile: function (wrapper, util, params, callback) {
            },
 
            load: function (params, callback) {
 
            },
 
            loadMobile: function (params, callback) {
            }
        };
    });