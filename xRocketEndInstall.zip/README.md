# xRocketEndInstall

This module is to copy files and SQL  required by RockCDS on installation.

Some SQL needs to be execute after all other DNN modules.  (Personabar)

There is no compile on this modules.

To build the install package, zip the files into a zip file called "xRocketEndInstall.zip", this fil ethen needs to be the release for the GitHub project.



